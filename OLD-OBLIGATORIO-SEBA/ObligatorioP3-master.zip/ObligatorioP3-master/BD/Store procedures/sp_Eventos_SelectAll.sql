CREATE PROCEDURE Eventos_SelectAll
	As
	BEGIN
		SET NOCOUNT ON
		Select * 
		From Eventos
			END
			GO